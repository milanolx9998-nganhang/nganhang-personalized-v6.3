const { Service } = require('node-windows');
const path = require('path');
const svc = new Service({
  name: 'NganHangV4',
  description: 'Ngan Hang Cau Hoi V4.3 - Server mang LAN',
  script: path.join('C:\\Users\\Duong Hieu\\Desktop\\ngan hang cau hoi\\nganhang-v4.3.3\\nganhang-v4', 'backend', 'src', 'server.js'),
  nodeOptions: [],
  workingDirectory: path.join('C:\\Users\\Duong Hieu\\Desktop\\ngan hang cau hoi\\nganhang-v4.3.3\\nganhang-v4', 'backend'),
  env: [
    { name: 'NODE_ENV', value: 'production' }
  ]
});
svc.on('install', () => {
  console.log('[OK] Da cai service NganHangV4');
  svc.start();
});
svc.on('start', () => {
  console.log('[OK] Service da khoi dong');
  console.log('Server: http://localhost:3000');
});
svc.on('error', (err) => {
  console.error('[X] Loi:', err);
});
svc.install();
