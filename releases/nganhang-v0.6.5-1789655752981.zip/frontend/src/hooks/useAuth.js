import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { api, setToken } from '../api/client.js';

export const useAuth = create(
  persist(
    (set) => ({
      user: null,
      token: null,
      async login(username, password) {
        const data = await api.post('/api/auth/login', { username, password });
        setToken(data.token);
        set({ user: data.user, token: data.token });
        return data;
      },
      async refreshMe() {
        try {
          const user = await api.get('/api/auth/me');
          set({ user });
        } catch { /* ignore */ }
      },
      async logout() {
        try{await api.post('/api/auth/logout',{});}catch{}
        setToken(null);
        set({ user: null, token: null });
      },
    }),
    { name: 'nganhang_auth' }
  )
);

export function hasCapability(user,key){return user?.capabilities?.[key]===true;}
export function hasAnyCapability(user,keys){return keys.some(key=>hasCapability(user,key));}
// Compatibility wrappers; no longer derive permissions from role names.
export function can(user,capabilities){return hasAnyCapability(user,Array.isArray(capabilities)?capabilities:[capabilities]);}
export function isReadOnly(user){return !hasAnyCapability(user,['content.write','content.review','content.approve']);}
export function canManage(user){return hasCapability(user,'content.write');}
export function canReview(user){return hasCapability(user,'content.review');}
export const ROLE_LABEL = {
  admin: 'Quản trị',
  board: 'BGH (chỉ xem)',
  viewer:'Người xem được phân quyền',
  student:'Học sinh',
  dept_leader: 'Tổ trưởng',
  grade_leader: 'Nhóm trưởng',
  teacher: 'Giáo viên',
};
