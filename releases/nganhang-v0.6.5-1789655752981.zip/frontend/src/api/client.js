const BASE = '';

export function getToken() {
  return localStorage.getItem('nganhang_token');
}

export function setToken(t) {
  if (t) localStorage.setItem('nganhang_token', t);
  else localStorage.removeItem('nganhang_token');
}

async function request(method, url, body) {
  const headers = { 'Content-Type': 'application/json' };
  const t = getToken();
  if (t) headers['Authorization'] = `Bearer ${t}`;

  const opts = { method, headers };
  if (body !== undefined) opts.body = JSON.stringify(body);

  const res = await fetch(BASE + url, opts);
  if (res.status === 401 && !url.includes('/auth/login')) {
    setToken(null);
    if (!url.includes('/auth/login')) window.location.href = '/login';
    throw new Error('Phiên đăng nhập hết hạn');
  }
  const contentType = res.headers.get('content-type') || '';
  let data;
  if (contentType.includes('application/json')) {
    data = await res.json();
  } else {
    data = await res.text();
  }
  if (!res.ok) {
    throw Object.assign(new Error(data?.error || data?.message || `Lỗi ${res.status}`),{code:data?.code,details:data?.details,status:res.status});
  }
  return data;
}

export const api = {
  get:  (url) => request('GET', url),
  post: (url, body) => request('POST', url, body),
  put:  (url, body) => request('PUT', url, body),
  patch: (url, body) => request('PATCH', url, body),
  del:  (url,body) => request('DELETE', url,body),
};

export async function downloadFile(url, filename) {
  const t = getToken();
  const res = await fetch(BASE + url, { headers: t ? { Authorization: `Bearer ${t}` } : {} });
  if (!res.ok) throw new Error('Tải xuống thất bại');
  const blob = await res.blob();
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = filename || 'download';
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(link.href);
}

export async function uploadFile(url, file, extraFields = {}) {
  const t = getToken();
  const form = new FormData();
  form.append('file', file);
  for (const [k, v] of Object.entries(extraFields)) {
    if (v !== undefined && v !== null) form.append(k, v);
  }
  const res = await fetch(BASE + url, {
    method: 'POST',
    headers: t ? { Authorization: `Bearer ${t}` } : {},
    body: form,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.error || `Lỗi ${res.status}`);
  return data;
}
