import {can} from '../accessResolver.js';
// Also strips nested legacy snapshots; removing only answer_key would leak the same key through content.
const privateKeys=new Set(['answer','answer_key','explanation','correct','is_correct','correct_answer','reference_answer','rubric','sample_answer','original_answer','q_answer_key','source_path','source_document','source_locator']);
function redact(value){if(Array.isArray(value))return value.map(redact);if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).filter(([key])=>!privateKeys.has(key)).map(([key,v])=>[key,redact(v)]));return value;}
export async function visibleQuestion(user,question,client){
 const allowed=await can(user,'content.view_answer',{subjectId:question.subject_id,grade:question.grade,bankId:question.bank_id},client);
 return allowed?question:{...redact(question),answer_hidden:true};
}
