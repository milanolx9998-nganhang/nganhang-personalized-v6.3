// Danh mục hữu hạn: không nhận wildcard hoặc biểu thức quyền từ client.
const domains={
 student:['read','manage_basic','reset_password','transfer','disable'],
 learning:['read','read_attempt','read_all_subjects','read_subject'],
 content:['read','write','create_version','review','approve','export','view_answer','download_source'],
 assignment:['create','manage','read'],matrix:['read','create','review','approve','lock'],
 exam:['read','create','generate'],bank:['read','write','review','manage'],
 curriculum:['read','manage','manage_lessons','manage_standards','propose_mapping','publish'],
 analytics:['read','export'],staff:['read','manage'],class:['manage','manage_membership'],
 audit:['read'],security:['read'],system:['config']
};
export const CAPABILITIES=Object.freeze(Object.entries(domains).flatMap(([domain,actions])=>actions.map(a=>`${domain}.${a}`)));
export const HIGH_RISK=new Set(['content.approve','content.export','content.download_source','matrix.approve','matrix.lock','curriculum.publish','staff.manage','system.config','student.reset_password','student.transfer','student.disable','bank.manage','analytics.export']);
export const SCHOOL_LEVELS=Object.freeze({THCS:[6,7,8,9],THPT:[10,11,12]});
export const POSITION_LABELS=Object.freeze({SUBJECT_TEACHER:'Giáo viên bộ môn',HOMEROOM:'Giáo viên chủ nhiệm',DEPT_LEADER:'Tổ trưởng chuyên môn',GRADE_LEADER:'Khối trưởng',BOARD:'Ban giám hiệu',VIEWER:'Người xem',ADMIN:'Quản trị hệ thống'});
const teaching=['student.read','learning.read','learning.read_attempt','learning.read_subject','content.read','content.write','content.create_version','content.export','content.view_answer','content.download_source','assignment.create','assignment.manage','assignment.read','matrix.read','matrix.create','exam.read','exam.create','exam.generate','bank.read','bank.write','curriculum.read','curriculum.manage_lessons','analytics.read'];
const learning=['student.read','learning.read','learning.read_attempt','learning.read_all_subjects','assignment.read','analytics.read'];
const read=['student.read','learning.read','learning.read_attempt','content.read','content.view_answer','assignment.read','matrix.read','exam.read','bank.read','curriculum.read','analytics.read'];
export const PRESETS=Object.freeze({
 SUBJECT_TEACHER:teaching,
 HOMEROOM:[...learning,'student.manage_basic','student.reset_password'],
 DEPT_LEADER:[...teaching,'content.review','content.approve','matrix.review','matrix.approve','matrix.lock','bank.review','curriculum.propose_mapping','analytics.export'],
 GRADE_LEADER:learning,
 BOARD:[...read,'learning.read_all_subjects','analytics.export','audit.read'],
 VIEWER:read,
 ADMIN:CAPABILITIES
});
export const SCOPE_TYPES=['WHOLE_SCHOOL','SCHOOL_LEVEL','GRADE','DEPARTMENT','SUBJECT','CLASS','BANK','CUSTOM'];
