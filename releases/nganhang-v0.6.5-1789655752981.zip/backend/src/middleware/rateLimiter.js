import rateLimit,{ipKeyGenerator} from 'express-rate-limit';

// Login: 5 lần thử / 15 phút / IP
export const loginLimiter = rateLimit({
  // Chỉ bỏ giới hạn khi demo được bật rõ ràng và server bind loopback.
  skip: () => process.env.DEMO_DISABLE_LOGIN_LIMIT === 'true'
    && process.env.NODE_ENV !== 'production'
    && ['127.0.0.1', 'localhost', '::1'].includes(process.env.HOST),
  windowMs: 15 * 60 * 1000,
  max: 5,
  skipSuccessfulRequests: true,
  message: { error: 'Quá nhiều lần đăng nhập. Vui lòng thử lại sau 15 phút.' },
  standardHeaders: true,
  legacyHeaders: false,
});

// API chung: 200 request / phút / IP
export const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 300,
  keyGenerator:req=>req.user?.id?'user:'+req.user.id:ipKeyGenerator(req.ip),
  message: { error: 'Quá nhiều yêu cầu. Vui lòng chờ 1 phút.' },
  standardHeaders: true,
  legacyHeaders: false,
});

// Upload: 10 lần / phút / IP
export const uploadLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 10,
  message: { error: 'Quá nhiều file upload. Vui lòng chờ.' },
  standardHeaders: true,
  legacyHeaders: false,
});
