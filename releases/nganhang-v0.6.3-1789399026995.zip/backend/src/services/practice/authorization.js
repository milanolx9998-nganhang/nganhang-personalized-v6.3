import {pool} from '../../db/pool.js';
import {checkSubjectAccess} from '../../middleware/auth.js';
import {fail} from './config.js';
export function staff(user){if(['student','viewer','board'].includes(user.role))fail('Tài khoản không có quyền chỉnh sửa',403);}
export async function subjectAccess(user,id){if(user.role==='student')return true;if(!await checkSubjectAccess(user,id))fail('Không có quyền với môn này',403);return true;}
export async function classAccess(user,classId,client=pool,write=false){
 if(write)staff(user);if(user.role==='admin')return true;
 const {rowCount}=await client.query('SELECT 1 FROM learning_class_scopes WHERE teacher_id=$1 AND class_id=$2',[user.id,classId]);
 if(!rowCount)fail('Lớp chưa được phân quyền cho tài khoản',403);return true;
}
export async function studentAccess(user,studentId,client=pool){
 if(user.role==='admin'||user.role==='student'&&user.id===Number(studentId))return true;
 if(user.role==='student')fail('Chỉ được xem dữ liệu của mình',403);
 const {rowCount}=await client.query('SELECT 1 FROM class_memberships m JOIN learning_class_scopes t ON t.class_id=m.class_id WHERE m.student_id=$1 AND t.teacher_id=$2 AND m.ended_at IS NULL AND m.valid_from<=CURRENT_DATE AND (m.valid_to IS NULL OR m.valid_to>=CURRENT_DATE)',[studentId,user.id]);
 if(!rowCount)fail('Học sinh ngoài phạm vi được giao',403);return true;
}
export async function bankAccess(user,bankId,permission='read',client=pool){
 const bank=(await client.query('SELECT * FROM banks WHERE id=$1',[bankId])).rows[0];
 if(!bank)fail('Không tìm thấy kho',404);
 if(user.role==='admin')return bank;
 if(permission!=='read'&&!(permission==='review'&&user.role==='board'&&user.capabilities?.content_review))staff(user);
 if(bank.owner_id===user.id)return bank;
 const membership=(await client.query('SELECT permission FROM bank_memberships WHERE bank_id=$1 AND user_id=$2',[bankId,user.id])).rows[0];
 if(membership&&({read:1,write:2,review:3}[membership.permission]>=({read:1,write:2,review:3}[permission])))return bank;
 if(bank.kind==='department'&&bank.department_id===user.department_id&&(permission==='read'||['dept_leader','grade_leader'].includes(user.role)))return bank;
 if(bank.kind==='school'&&permission==='read')return bank;
 fail('Không có quyền với kho này',403);
}
export async function assignmentAccess(user,assignment,client=pool){
 if(!assignment)fail('Không tìm thấy bài giao',404);
 if(user.role!=='student'){if(user.role==='admin'||assignment.created_by===user.id)return true;fail('Không có quyền với bài giao',403);}
 const result=await client.query('SELECT 1 FROM assignment_targets t WHERE t.assignment_id=$1 AND (t.student_id=$2 OR t.class_id IN (SELECT class_id FROM class_memberships WHERE student_id=$2 AND ended_at IS NULL AND valid_from<=CURRENT_DATE AND (valid_to IS NULL OR valid_to>=CURRENT_DATE)))',[assignment.id,user.id]);
 if(!result.rowCount)fail('Bài này chưa được giao cho em',403);return true;
}
