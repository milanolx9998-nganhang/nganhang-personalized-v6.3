import {pool} from '../db/pool.js';
export async function positions(user,client=pool){
 return (await client.query('SELECT * FROM user_positions WHERE user_id=$1 AND valid_from<=CURRENT_DATE AND (valid_to IS NULL OR valid_to>=CURRENT_DATE)',[user.id])).rows;
}
export async function contentSubjects(user,client=pool){
 if(user.role==='admin')return null;
 const ps=await positions(user,client);
 const ids=new Set(user.subject_id?[user.subject_id]:[]);
 for(const row of (await client.query('SELECT DISTINCT subject_id FROM teacher_class_assignments WHERE teacher_id=$1',[user.id])).rows)ids.add(row.subject_id);
 const departments=new Set(user.role==='dept_leader'&&user.department_id?[user.department_id]:[]);
 for(const p of ps){
  if(['subject_teacher','dept_leader','board'].includes(p.position)&&p.subject_id)ids.add(p.subject_id);
  if(['dept_leader','board'].includes(p.position)&&p.department_id)departments.add(p.department_id);
 }
 if(departments.size)for(const s of (await client.query('SELECT id FROM subjects WHERE department_id=ANY($1::int[])',[[...departments]])).rows)ids.add(s.id);
 return [...ids];
}
export async function contentCapability(user,action,subjectId,client=pool){
 if(user.role==='admin')return true;
 const ps=await positions(user,client),subject=(await client.query('SELECT department_id FROM subjects WHERE id=$1',[subjectId])).rows[0];
 if(!subject)return false;
 const ownSubject=(await contentSubjects(user,client)).includes(Number(subjectId));
 if(action==='read')return ownSubject;
 if(['student','viewer'].includes(user.role))return false;
 if(action==='review')return user.role==='dept_leader'&&user.department_id===subject.department_id||
  ps.some(p=>p.position==='dept_leader'&&p.department_id===subject.department_id||p.position==='board'&&p.can_approve&&(p.subject_id===Number(subjectId)||p.department_id===subject.department_id));
 const legacyTeaching=user.subject_id===Number(subjectId)||!!(await client.query('SELECT 1 FROM teacher_class_assignments WHERE teacher_id=$1 AND subject_id=$2 LIMIT 1',[user.id,subjectId])).rowCount;
 if(['teacher','dept_leader','grade_leader'].includes(user.role)&&(legacyTeaching||user.role==='dept_leader'&&user.department_id===subject.department_id))return true;
 return ps.some(p=>p.position==='subject_teacher'&&p.subject_id===Number(subjectId)||p.position==='dept_leader'&&p.department_id===subject.department_id);
}
export async function accountCapability(user,{classId=null,studentId=null}={},client=pool){
 if(user.role==='admin')return true;
 if(['student','viewer'].includes(user.role))return false;
 return !!(await client.query(`SELECT 1 FROM user_positions p WHERE p.user_id=$1 AND p.position='homeroom' AND p.valid_from<=CURRENT_DATE AND (p.valid_to IS NULL OR p.valid_to>=CURRENT_DATE)
 AND ($2::int IS NULL OR p.class_id=$2)
 AND ($3::int IS NULL OR EXISTS(SELECT 1 FROM class_memberships cm WHERE cm.class_id=p.class_id AND cm.student_id=$3 AND cm.ended_at IS NULL AND cm.valid_from<=CURRENT_DATE AND (cm.valid_to IS NULL OR cm.valid_to>=CURRENT_DATE))) LIMIT 1`,[user.id,classId,studentId])).rowCount;
}
export async function capabilitySummary(user){
 const ps=await positions(user);
 const teaching=user.subject_id||!!(await pool.query('SELECT 1 FROM teacher_class_assignments WHERE teacher_id=$1 LIMIT 1',[user.id])).rowCount;
 return {positions:ps,capabilities:{student_accounts:user.role==='admin'||ps.some(p=>p.position==='homeroom'),content_write:user.role==='admin'||user.role==='dept_leader'&&!!user.department_id||['teacher','dept_leader','grade_leader'].includes(user.role)&&!!teaching||ps.some(p=>['subject_teacher','dept_leader'].includes(p.position)),content_review:['admin','dept_leader'].includes(user.role)||ps.some(p=>p.position==='dept_leader'||p.position==='board'&&p.can_approve)}};
}
