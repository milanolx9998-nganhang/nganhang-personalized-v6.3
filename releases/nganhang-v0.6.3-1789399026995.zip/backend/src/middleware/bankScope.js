import {pool,tx} from '../db/pool.js';
import {bankAccess,subjectAccess,staff} from '../services/practice/authorization.js';
import {transition} from '../services/practice/questions.js';
import {fail} from '../services/practice/config.js';
export function bankFilter(user,alias,params){
 if(user.role==='admin')return 'TRUE';
 params.push(user.id,user.department_id||null);const uid='$'+(params.length-1),dep='$'+params.length;
 return `EXISTS(SELECT 1 FROM banks scope_bank WHERE scope_bank.id=${alias}.bank_id AND (scope_bank.kind='school' OR scope_bank.owner_id=${uid} OR scope_bank.kind='department' AND scope_bank.department_id=${dep} OR EXISTS(SELECT 1 FROM bank_memberships bm WHERE bm.bank_id=scope_bank.id AND bm.user_id=${uid})))`;
}
export async function legacyQuestionGuard(req,res,next){
 try{
  const id=req.path.match(/^\/(\d+)(?:\/|$)/)?.[1],ids=id?[Number(id)]:Array.isArray(req.body?.ids)?req.body.ids:[];
  const mutation=!['GET','HEAD'].includes(req.method);if(mutation)staff(req.user);
  const review=req.path.endsWith('/review')||req.path==='/bulk-review';
  if(ids.length){if(ids.length>500)fail('Tối đa 500 câu mỗi thao tác');const rows=(await pool.query('SELECT id,bank_id,subject_id,lifecycle FROM questions WHERE id=ANY($1::int[])',[ids])).rows;if(rows.length!==new Set(ids.map(Number)).size)fail('Không tìm thấy câu hỏi',404);
   for(const q of rows){await subjectAccess(req.user,q.subject_id);await bankAccess(req.user,q.bank_id,review?'review':mutation?'write':'read');}
   if(req.method==='DELETE'||req.path==='/bulk-delete'){await tx(async c=>{for(const q of rows)if(q.lifecycle!=='archived')await transition(c,req.user,q.id,'archived');});return res.json({ok:true,deleted:0,archived:rows.length,message:'Đã lưu trữ để giữ lịch sử luyện tập'});}
   if(review){const target={'Đã rà soát':'pending_review','Đã duyệt':'approved','Đã sử dụng':'active','Tạm ẩn':'archived','Mới tạo':'draft'}[req.body.status];if(!target)fail('Trạng thái không hợp lệ');await tx(async c=>{for(const q of rows)if(q.lifecycle!==target)await transition(c,req.user,q.id,target);});return res.json({ok:true,updated:rows.length});}
  }
  next();
 }catch(e){next(e);}
}
