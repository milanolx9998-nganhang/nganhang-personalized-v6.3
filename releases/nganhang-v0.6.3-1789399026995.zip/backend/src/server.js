import 'dotenv/config';
import {recordHttp} from './services/practice/operations.js';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import crypto from 'node:crypto';
import {pool} from './db/pool.js';
import {auth} from './middleware/auth.js';
import practiceRoutes from './routes/practice.js';

import { testConnection } from './db/pool.js';
import { errorHandler } from './middleware/errorHandler.js';
import { loginLimiter, apiLimiter, uploadLimiter } from './middleware/rateLimiter.js';
import { sanitizeBody } from './middleware/sanitize.js';

import authRoutes from './routes/auth.js';
import usersRoutes from './routes/users.js';
import taxonomyRoutes from './routes/taxonomy.js';
import questionsRoutes from './routes/questions.js';
import matrixRoutes from './routes/matrix.js';
import matrixBalanceRoutes from './routes/matrix-balance.js';
import examsRoutes from './routes/exams.js';
import reportsRoutes from './routes/reports.js';
import uploadsRoutes from './routes/uploads.js';
import tagsRoutes from './routes/tags.js';
import analysisRoutes from './routes/analysis.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
if(process.env.TRUST_PROXY)app.set('trust proxy',Number(process.env.TRUST_PROXY));
const PORT = parseInt(process.env.PORT || '3001', 10);
const HOST = process.env.HOST || '0.0.0.0';

app.use((req,res,next)=>{res.on('finish',()=>recordHttp(res.statusCode));req.requestId=crypto.randomUUID();res.setHeader('X-Request-ID',req.requestId);next();});
app.use(helmet({contentSecurityPolicy:{directives:{defaultSrc:["'self'"],scriptSrc:["'self'"],styleSrc:["'self'","'unsafe-inline'"],imgSrc:["'self'",'data:','https:'],fontSrc:["'self'"],frameAncestors:["'self'",...(process.env.CANVAS_ORIGINS||'').split(',').filter(Boolean)]}},frameguard:process.env.CANVAS_ORIGINS?false:{action:'sameorigin'}}));
const origins=(process.env.CORS_ORIGIN||'').split(',').filter(Boolean);
app.use(cors({origin:(origin,cb)=>cb(null,!origin||origins.includes(origin))}));
app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ extended: true, limit: '20mb' }));
app.use(morgan((tokens,req,res)=>JSON.stringify({request_id:req.requestId,method:req.method,path:req.path,status:Number(tokens.status(req,res)),duration_ms:Number(tokens['response-time'](req,res))})));
app.use(sanitizeBody);

const uploadDir = path.resolve(process.cwd(), process.env.UPLOAD_DIR || './uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
for(const folder of ['images','media'])app.use('/uploads/'+folder,(req,res,next)=>{if(!/\.(png|jpe?g|gif|webp)$/i.test(req.path))return res.sendStatus(404);next();},express.static(path.join(uploadDir,folder)));

app.get('/api/health', async (_req, res) => {
  try{await pool.query('SELECT 1');res.json({ status: 'ok', database:'ok', timestamp: new Date().toISOString(), version: '0.6.3-pilot' });}catch{res.status(503).json({status:'unavailable'});}
});

app.use('/api/auth/login', loginLimiter);
app.use('/api/auth', authRoutes);
app.use('/api',auth,(req,res,next)=>{
 if(req.user.must_change_password)return res.status(403).json({error:'Cần đổi mật khẩu trước khi tiếp tục'});
 if(req.user.role==='student'&&!req.path.startsWith('/practice/'))return res.status(403).json({error:'Học sinh chỉ được truy cập khu tự luyện'});
 const scopedBoardReview=req.user.role==='board'&&req.user.capabilities?.content_review&&(req.path.match(/^\/matrix\/\d+\/(workflow|toggle-lock)$/)||req.path.match(/^\/practice\/questions\/\d+\/workflow$/));
 const scopedBoardAccounts=req.user.role==='board'&&req.user.capabilities?.student_accounts&&(/^\/practice\/students(?:\/\d+\/(profile|reset-password))?$/.test(req.path)||/^\/practice\/roster(?:\/preview|\/confirm)?$/.test(req.path));
 if(['board','viewer'].includes(req.user.role)&&!['GET','HEAD','OPTIONS'].includes(req.method)&&!scopedBoardReview&&!scopedBoardAccounts)return res.status(403).json({error:'Tài khoản chỉ có quyền xem'});
 next();
});
app.use('/api/practice',apiLimiter,practiceRoutes);
app.use('/api/users', apiLimiter, usersRoutes);
app.use('/api/taxonomy', apiLimiter, taxonomyRoutes);
app.use('/api/questions', apiLimiter, questionsRoutes);
app.use('/api/matrix', apiLimiter, matrixRoutes);
app.use('/api/matrix-balance', apiLimiter, matrixBalanceRoutes);
app.use('/api/exams', apiLimiter, examsRoutes);
app.use('/api/reports', apiLimiter, reportsRoutes);
app.use('/api/uploads', uploadLimiter, uploadsRoutes);
app.use('/api/tags', apiLimiter, tagsRoutes);
app.use('/api/analysis', apiLimiter, analysisRoutes);

// Serve frontend production build
const frontendDist = path.resolve(__dirname, '../../frontend/dist');
if (fs.existsSync(frontendDist)) {
  app.use(express.static(frontendDist));
  app.get(/.*/, (req, res, next) => {
    if (req.path.startsWith('/api/')) return next();
    res.sendFile(path.join(frontendDist, 'index.html'));
  });
}

app.use(errorHandler);

(async () => {
  try {
    await testConnection();
    console.log('✓ Kết nối PostgreSQL thành công');
    app.listen(PORT, HOST, () => {
      console.log(`
Ngân hàng V4.3 đang chạy tại:
  http://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${PORT}

Máy khác trong LAN truy cập qua IP:
  http://<ip-máy-chủ>:${PORT}
`);
    });
  } catch (err) {
    console.error('❌ Lỗi kết nối DB:', err.message);
    console.error('Kiểm tra .env + PostgreSQL đã chạy chưa.');
    process.exit(1);
  }
})();
