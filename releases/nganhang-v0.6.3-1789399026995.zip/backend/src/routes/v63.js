import {questionList} from '../services/practice/questions.js';
import {questionWorkbook} from '../services/questionWorkbook.js';
import {Router} from 'express';
import {z} from 'zod';
import {pool,tx} from '../db/pool.js';
import {curriculumCatalog} from '../services/curriculum.js';
import {contentCapability} from '../services/capabilities.js';
import {enrichMetadata} from '../services/smartMetadata.js';
import {getSubjectFilterSQL} from '../middleware/auth.js';
import {studentAccess} from '../services/practice/authorization.js';
import {scopedSubjects} from '../services/practice/analytics.js';
import {log,fail} from '../services/practice/config.js';
import {bankFilter} from '../middleware/bankScope.js';
const r=Router(),wrap=fn=>async(req,res,next)=>{try{await fn(req,res);}catch(e){next(e);}};
const admin=(req,res,next)=>req.user.role==='admin'?next():res.status(403).json({error:'Chỉ quản trị được phân công vị trí'});
r.get('/questions-export',wrap(async(req,res)=>{if(req.user.role==='student')fail('Không đủ quyền',403);const rows=[];for(let offset=0;offset<=5000;offset+=100){const page=await questionList(req.user,{...req.query,offset,limit:100});rows.push(...page);if(rows.length>5000)fail('Bộ lọc vượt 5000 câu; hãy thu hẹp trước khi xuất',422);if(page.length<100)break;}res.type('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet').attachment('cau-hoi-advanced.xlsx').send(questionWorkbook(rows));}));
r.get('/curriculum',wrap(async(req,res)=>res.json(await curriculumCatalog(req.query))));
r.post('/metadata/suggest',wrap(async(req,res)=>{if(['student','viewer','board'].includes(req.user.role))fail('Không có quyền phân loại',403);const d=req.body;if(d.subject_id&&!await contentCapability(req.user,'write',d.subject_id))fail('Môn ngoài phạm vi',403);res.json(await enrichMetadata(pool,d));}));
r.get('/positions',admin,wrap(async(req,res)=>res.json((await pool.query('SELECT p.*,u.full_name,c.name AS class_name,s.name AS subject_name,d.name AS department_name FROM user_positions p JOIN users u ON u.id=p.user_id LEFT JOIN classes c ON c.id=p.class_id LEFT JOIN subjects s ON s.id=p.subject_id LEFT JOIN departments d ON d.id=p.department_id ORDER BY p.id DESC')).rows)));
r.post('/positions',admin,wrap(async(req,res)=>{
 const id=z.number().int().positive().nullable().default(null);
 const d=z.object({user_id:z.number().int().positive(),position:z.enum(['subject_teacher','homeroom','dept_leader','grade_leader','board']),class_id:id,subject_id:id,department_id:id,grade:z.number().int().min(1).max(12).nullable().default(null),school_year_id:id,can_approve:z.boolean().default(false),valid_from:z.string().date().optional(),valid_to:z.string().date().nullable().default(null)}).parse(req.body);
 const result=await tx(async c=>{
  const user=(await c.query('SELECT role FROM users WHERE id=$1 AND is_active',[d.user_id])).rows[0];if(!user||['student','viewer'].includes(user.role))fail('Chọn tài khoản nhân sự đang hoạt động');
  if(d.position==='homeroom'&&(!d.class_id||d.subject_id)||d.position==='subject_teacher'&&!d.subject_id||d.position==='dept_leader'&&!d.department_id||d.position==='grade_leader'&&(!d.grade||!d.school_year_id)||d.position==='board'&&!d.class_id&&!d.subject_id&&!d.department_id&&!(d.grade&&d.school_year_id))fail('Cần xác định phạm vi đúng với vị trí');
  if(d.position==='homeroom'&&(d.grade||d.department_id||d.school_year_id))fail('GVCN dùng phạm vi lớp; không gán thêm bộ lọc khác');
  const row=(await c.query('INSERT INTO user_positions(user_id,position,class_id,subject_id,department_id,grade,school_year_id,can_approve,valid_from,valid_to) VALUES($1,$2,$3,$4,$5,$6,$7,$8,COALESCE($9::date,CURRENT_DATE),$10) RETURNING *',[d.user_id,d.position,d.class_id,d.subject_id,d.department_id,d.grade,d.school_year_id,d.can_approve,d.valid_from||null,d.valid_to])).rows[0];
  await log(c,req.user,'POSITION_ASSIGNED',row.id,d);return row;
 });res.status(201).json(result);
}));
r.delete('/positions/:id',admin,wrap(async(req,res)=>{await tx(async c=>{const row=(await c.query('DELETE FROM user_positions WHERE id=$1 RETURNING *',[req.params.id])).rows[0];if(!row)fail('Không tìm thấy vị trí',404);await log(c,req.user,'POSITION_REVOKED',row.id,row);});res.json({ok:true});}));
r.get('/question-quality',wrap(async(req,res)=>{
 if(req.user.role==='student')fail('Trang dành cho nhân sự',403);
 const params=[],where=[bankFilter(req.user,'q',params)],sf=await getSubjectFilterSQL(req.user,'q',params.length+1);if(sf.clause){where.push(sf.clause);params.push(...sf.params);}
 for(const key of ['subject_id','grade','yccd_id'])if(req.query[key]){params.push(req.query[key]);where.push('q.'+key+'=$'+params.length);}
 const rows=(await pool.query(`SELECT q.id,q.question_code,q.stem_text,q.yccd_id,q.metadata_status,q.lifecycle,q.usage_count,
 count(i.id) FILTER(WHERE a.status='completed')::int answered_items,count(DISTINCT a.student_id) FILTER(WHERE a.status='completed')::int unique_students,
 count(i.id) FILTER(WHERE a.status='completed' AND i.grade_result->>'isCorrect'='true')::int correct,
 count(i.id) FILTER(WHERE a.status='completed' AND (i.grade_result->>'score')::numeric>0 AND (i.grade_result->>'score')::numeric<1)::int partial,
 count(i.id) FILTER(WHERE a.status='completed' AND i.skipped)::int skipped,count(i.id) FILTER(WHERE a.status='completed' AND i.uncertain)::int uncertain,
 (SELECT count(DISTINCT er.creator_id)::int FROM exam_items ei JOIN exam_runs er ON er.id=ei.run_id WHERE ei.question_id=q.id) teacher_reuse,
 NULL::numeric median_time_seconds,NULL::int report_count
 FROM questions q LEFT JOIN attempt_items i ON i.question_id=q.id LEFT JOIN attempts a ON a.id=i.attempt_id
 WHERE ${where.join(' AND ')} GROUP BY q.id ORDER BY q.id DESC LIMIT 200`,params)).rows;
 res.json({questions:rows,uncollected:['Thời gian hoạt động từng câu chưa được thu thập chính xác','Chưa có chức năng báo lỗi câu hỏi; không thay bằng số 0']});
}));
r.get('/learning-map/:studentId',wrap(async(req,res)=>{
 const id=Number(req.params.studentId);await studentAccess(req.user,id);const subjects=await scopedSubjects(req.user,{studentId:id});
 const rows=(await pool.query(`SELECT y.id AS yccd_id,y.code,y.text,o.id AS outcome_id,o.code AS outcome_code,o.subject_id,o.grade,
 count(i.id)::int evidence_count,count(DISTINCT a.id)::int attempts,count(DISTINCT qv.question_id)::int unique_questions,
 avg((i.grade_result->>'score')::numeric)*100 AS observed_score
 FROM attempt_items i JOIN attempts a ON a.id=i.attempt_id JOIN question_versions qv ON qv.id=i.question_version_id
 JOIN curriculum_yccds y ON y.id=qv.yccd_id JOIN curriculum_outcomes o ON o.id=y.outcome_id
 WHERE a.student_id=$1 AND a.status='completed' AND ($2::int[] IS NULL OR qv.subject_id=ANY($2))
 GROUP BY y.id,o.id ORDER BY o.id,y.id`,[id,subjects])).rows;
 res.json({rows:rows.map(x=>({...x,confidence:x.unique_questions>=10&&x.attempts>=3?'MEDIUM':'LOW',interpretation:x.unique_questions>=10&&x.attempts>=3?(Number(x.observed_score)>=80?'Điểm mạnh quan sát được':Number(x.observed_score)<50?'Cần củng cố':'Đang hình thành'):'Chưa đủ bằng chứng để kết luận'})),note:'Tổng hợp bằng chứng theo phiên bản đã làm, không thay công thức Mastery. Lượt cũ chưa gắn YCCĐ vẫn xem ở bản đồ theo bài.'});
}));
export default r;
