const editors=['admin','teacher','dept_leader','grade_leader'];
export const staffGroups=[
 {id:'learning',label:'Học sinh & Học tập',description:'Theo dõi lớp và hành trình học tập của từng em.',children:[{to:'/practice',label:'Tiến độ lớp',end:true},{to:'/practice/students',label:'Quản lý học sinh'}]},
 {id:'content',label:'Ngân hàng & Nội dung',description:'Biên soạn, nhập và duyệt nguồn câu hỏi.',children:[{to:'/practice/banks',label:'Kho câu hỏi · Duyệt câu'},{to:'/questions',label:'Câu hỏi'},{to:'/practice/import',label:'Nhập Word · Excel · QTI',roles:editors},{to:'/taxonomy',label:'Môn học · Chương · Bài',roles:['admin','board','dept_leader','grade_leader']},{to:'/tags',label:'Nhãn',roles:['admin','board','dept_leader','grade_leader']}]},
 {id:'assign',label:'Tạo & Giao bài',description:'Giao bài luyện, tạo đề và xuất phiếu học tập.',children:[{to:'/practice/assignments',label:'Giao bài · Xuất phiếu'},{to:'/matrix',label:'Ma trận đề'},{to:'/exams',label:'Đề thi'}]},
 {id:'reports',label:'Báo cáo & Phân tích',description:'Đọc kết quả và nhận diện nội dung cần củng cố.',children:[{to:'/reports',label:'Báo cáo'},{to:'/analysis',label:'Phân tích',roles:['admin','board','dept_leader','grade_leader']},{to:'/dashboard',label:'Thống kê ngân hàng'}]},
 {id:'admin',label:'Quản trị hệ thống',description:'Tài khoản, lớp, năm học, cấu hình và nhật ký.',children:[{to:'/users',label:'Người dùng & phân quyền',roles:['admin','board']},{to:'/practice/admin',label:'Lớp · Cấu hình · Nhật ký',roles:['admin']}]}
];
export const studentLinks=[{to:'/practice',label:'Trang học tập',end:true},{to:'/practice/new',label:'Tự luyện'},{to:'/practice/assignments',label:'Bài được giao'},{to:'/practice/portfolio',label:'Hồ sơ học tập'},{to:'/practice/password',label:'Tài khoản'}];
export function groupsFor(user){return staffGroups.map(g=>({...g,children:g.children.filter(c=>!c.roles||c.roles.includes(user.role))})).filter(g=>g.children.length);}
export function activeGroup(path,groups){if(path.includes('/portfolio')||/^\/practice\/students\//.test(path))return 'learning';return groups.find(g=>g.children.some(c=>c.end?path===c.to:path===c.to||path.startsWith(c.to+'/')))?.id;}
