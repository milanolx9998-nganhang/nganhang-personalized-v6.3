import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { api, setToken } from '../api/client.js';

export const useAuth = create(
  persist(
    (set) => ({
      user: null,
      token: null,
      async login(username, password) {
        const data = await api.post('/api/auth/login', { username, password });
        setToken(data.token);
        set({ user: data.user, token: data.token });
        return data;
      },
      async refreshMe() {
        try {
          const user = await api.get('/api/auth/me');
          set({ user });
        } catch { /* ignore */ }
      },
      async logout() {
        try{await api.post('/api/auth/logout',{});}catch{}
        setToken(null);
        set({ user: null, token: null });
      },
    }),
    { name: 'nganhang_auth' }
  )
);

// Helper kiểm tra quyền
export function can(user, roles) {
  if (!user) return false;
  if (user.role === 'admin') return true;
  const list = Array.isArray(roles) ? roles : [roles];
  return list.includes(user.role);
}

// Giáo viên chỉ xem (read-only)
export function isReadOnly(user) {
  return user && user.role === 'teacher';
}

// Có quyền quản lý (tạo/sửa/xóa) — từ grade_leader trở lên
export function canManage(user) {
  if (!user) return false;
  return ['admin', 'board', 'dept_leader', 'grade_leader'].includes(user.role);
}

// Có thể duyệt câu hỏi
export function canReview(user) {
  if (!user) return false;
  return ['admin', 'board', 'dept_leader', 'grade_leader'].includes(user.role);
}

export const ROLE_LABEL = {
  admin: 'Quản trị',
  board: 'BGH (chỉ xem)',
  viewer:'Người xem được phân quyền',
  student:'Học sinh',
  dept_leader: 'Tổ trưởng',
  grade_leader: 'Nhóm trưởng',
  teacher: 'Giáo viên',
};
