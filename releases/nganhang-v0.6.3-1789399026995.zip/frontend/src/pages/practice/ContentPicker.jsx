import {useEffect,useState} from 'react';
import {api} from '../../api/client.js';

export default function ContentPicker({value,onChange,topics}){
 const mode=value.selection_mode||'topic',selected=mode==='yccd'?(value.yccd_keys||[]):value.topic_ids;
 const [search,setSearch]=useState(''),[remote,setRemote]=useState(null),[error,setError]=useState('');
 const scope=value.subject_id+':'+value.grade;
 useEffect(()=>{setSearch('');},[scope,mode]);
 useEffect(()=>{let active=true;setRemote(null);setError('');if(mode==='yccd'&&value.subject_id)api.get('/api/practice/content-options?'+new URLSearchParams({subject_id:value.subject_id,grade:value.grade})).then(data=>{if(active)setRemote({scope,data});}).catch(e=>{if(active)setError(e.message);});return()=>{active=false;};},[scope,mode]);
 const loading=mode==='yccd'&&value.subject_id&&remote?.scope!==scope&&!error;
 const items=mode==='topic'?topics.map(t=>({key:t.id,name:t.name,context:t.chapter||''})):(remote?.scope===scope?remote.data.yccd:[]);
 const normalized=s=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').toLocaleLowerCase('vi');
 const filtered=items.filter(i=>normalized(i.name+' '+i.context).includes(normalized(search)));
 const change=keys=>onChange({...value,selection_mode:mode,topic_ids:mode==='topic'?keys:[],yccd_keys:mode==='yccd'?keys:[]});
 return <fieldset className="wide content-picker"><legend>Nội dung muốn luyện</legend>
  <div className="scope-modes" role="group" aria-label="Chọn nội dung theo"><button type="button" className="btn" aria-pressed={mode==='topic'} onClick={()=>onChange({...value,selection_mode:'topic',topic_ids:[],yccd_keys:[]})}>Theo bài / chuyên đề</button><button type="button" className="btn" aria-pressed={mode==='yccd'} onClick={()=>onChange({...value,selection_mode:'yccd',topic_ids:[],yccd_keys:[]})}>Theo YCCĐ</button></div>
  <p>Tick vào từng {mode==='topic'?'bài / chuyên đề':'yêu cầu cần đạt'} muốn luyện. Có thể chọn nhiều mục, không cần giữ Ctrl.</p>
  {!value.subject_id?<p>Chọn môn và khối để xem nội dung.</p>:<>
   <label>Tìm {mode==='topic'?'bài / chuyên đề':'YCCĐ'}<input type="search" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Nhập tên hoặc mã để tìm…"/></label>
   <div className="scope-toolbar"><span role="status">Đã chọn {selected.length} mục</span><button type="button" className="btn" disabled={!filtered.length||new Set([...selected,...filtered.map(i=>i.key)]).size>100} onClick={()=>change([...new Set([...selected,...filtered.map(i=>i.key)])])}>Chọn tất cả đang hiện</button><button type="button" className="btn" disabled={!selected.length} onClick={()=>change([])}>Bỏ chọn tất cả</button></div>
   {loading&&<p role="status">Đang tải YCCĐ có câu hỏi được phép luyện…</p>}{error&&<p role="alert" className="practice-error">{error}</p>}
   {!loading&&!error&&!items.length&&<p className="scope-empty">{mode==='yccd'?'Chưa có câu hỏi được ánh xạ YCCĐ trong môn / khối này và phạm vi kho em được dùng. Em có thể chọn theo bài; giáo viên cần gắn YCCĐ đúng nguồn cho câu hỏi trước.':'Chưa có bài / chuyên đề cho môn và khối này.'}</p>}
   {!!items.length&&!filtered.length&&<p>Không tìm thấy mục phù hợp. Các mục đã tick vẫn được giữ.</p>}
   <div className="scope-options">{filtered.map(i=><label className={'scope-option'+(selected.includes(i.key)?' selected':'')} key={i.key}><input type="checkbox" checked={selected.includes(i.key)} disabled={!selected.includes(i.key)&&selected.length>=100} onChange={e=>change(e.target.checked?[...selected,i.key]:selected.filter(k=>k!==i.key))}/><span><strong>{i.name}</strong>{i.context&&<small>{i.context}</small>}{i.question_count!=null&&<small>{i.question_count} câu trong kho · số câu theo mức độ/dạng sẽ được kiểm tra ở bước sau</small>}</span></label>)}</div>
   <small>Tối đa 100 mục. Đổi môn, khối hoặc cách chọn sẽ xóa lựa chọn cũ.</small>
  </>}
 </fieldset>;
}
