import { useEffect, useState } from 'react';
import { api } from '../api/client.js';
import { ROLE_LABEL } from '../hooks/useAuth.js';

export default function Users() {
  const [users, setUsers] = useState([]);
  const [editing, setEditing] = useState(null);
  const [resetting, setResetting] = useState(null);

  const load = () => api.get('/api/users').then(setUsers);
  useEffect(() => { load(); }, []);

  const toggleActive = async (u) => {
    try { await api.put(`/api/users/${u.id}`, { is_active: !u.is_active }); load(); }
    catch (e) { alert(e.message); }
  };

  return (
    <div>
      <div className="page-header">
        <h2>👥 Người dùng <span className="badge">{users.length}</span></h2>
        <button className="btn primary" onClick={() => setEditing({})}>+ Thêm người dùng</button>
      </div>

      <div className="card" style={{ padding: 0 }}>
        <table>
          <thead>
            <tr>
              <th>Username</th>
              <th>Họ tên</th>
              <th>Vai trò</th>
              <th>Tổ · Môn</th>
              <th>Lần đăng nhập cuối</th>
              <th>Trạng thái</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {users.map(u => (
              <tr key={u.id}>
                <td><code>{u.username}</code></td>
                <td>{u.full_name}</td>
                <td><span className="badge info">{ROLE_LABEL[u.role] || u.role}</span></td>
                <td style={{ fontSize: 12 }}>{u.department_name || '-'} / {u.subject_name || '-'}</td>
                <td style={{ fontSize: 12 }}>{u.last_login ? new Date(u.last_login).toLocaleString('vi-VN') : 'Chưa từng'}</td>
                <td>{u.is_active ? <span className="badge success">Hoạt động</span> : <span className="badge danger">Khóa</span>}</td>
                <td style={{ whiteSpace: 'nowrap' }}>
                  <button className="btn ghost sm" onClick={() => setEditing(u)}>Sửa</button>
                  <button className="btn ghost sm" onClick={() => setResetting(u)}>Đặt lại MK</button>
                  <button className="btn ghost sm" onClick={() => toggleActive(u)}>
                    {u.is_active ? 'Khóa' : 'Mở'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {editing !== null && <UserModal user={editing} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); load(); }} />}
      {resetting && <ResetModal user={resetting} onClose={() => setResetting(null)} />}
    </div>
  );
}

function UserModal({ user, onClose, onSaved }) {
  const isNew = !user.id;
  const [depts, setDepts] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [data, setData] = useState({
    username: user.username || '',
    password: '',
    full_name: user.full_name || '',
    email: user.email || '',
    role: user.role || 'teacher',
    department_id: user.department_id || '',
    subject_id: user.subject_id || '',
  });

  useEffect(() => {
    api.get('/api/taxonomy/departments').then(setDepts);
    api.get('/api/taxonomy/subjects').then(setSubjects);
  }, []);

  const save = async () => {
    try {
      const payload = {
        full_name: data.full_name,
        email: data.email || '',
        role: data.role,
        department_id: data.department_id ? Number(data.department_id) : null,
        subject_id: data.subject_id ? Number(data.subject_id) : null,
      };
      if (isNew) {
        if (!data.username.trim() || data.password.length < 6) return alert('Username và mật khẩu ≥ 6 ký tự');
        await api.post('/api/users', { ...payload, username: data.username, password: data.password });
      } else {
        await api.put(`/api/users/${user.id}`, payload);
      }
      onSaved();
    } catch (e) { alert(e.message); }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <h3>{isNew ? '+ Thêm người dùng' : 'Sửa thông tin'}</h3>
        {isNew && (
          <>
            <div style={{ marginBottom: 10 }}>
              <label className="label">Username</label>
              <input value={data.username} onChange={e => setData(d => ({ ...d, username: e.target.value }))} style={{ width: '100%' }} />
            </div>
            <div style={{ marginBottom: 10 }}>
              <label className="label">Mật khẩu (≥ 6 ký tự)</label>
              <input type="password" value={data.password} onChange={e => setData(d => ({ ...d, password: e.target.value }))} style={{ width: '100%' }} />
            </div>
          </>
        )}
        <div style={{ marginBottom: 10 }}>
          <label className="label">Họ tên</label>
          <input value={data.full_name} onChange={e => setData(d => ({ ...d, full_name: e.target.value }))} style={{ width: '100%' }} />
        </div>
        <div style={{ marginBottom: 10 }}>
          <label className="label">Email (tùy chọn)</label>
          <input type="email" value={data.email} onChange={e => setData(d => ({ ...d, email: e.target.value }))} style={{ width: '100%' }} />
        </div>
        <div className="row" style={{ marginBottom: 10 }}>
          <div style={{ flex: 1 }}>
            <label className="label">Vai trò</label>
            <select value={data.role} onChange={e => setData(d => ({ ...d, role: e.target.value }))} style={{ width: '100%' }}>
              {Object.entries(ROLE_LABEL).filter(([k])=>k!=='student'||data.role==='student').map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </div>
          <div style={{ flex: 1 }}>
            <label className="label">Tổ bộ môn</label>
            <select value={data.department_id} onChange={e => setData(d => ({ ...d, department_id: e.target.value }))} style={{ width: '100%' }}>
              <option value="">--</option>
              {depts.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          </div>
          <div style={{ flex: 1 }}>
            <label className="label">Môn phụ trách</label>
            <select value={data.subject_id} onChange={e => setData(d => ({ ...d, subject_id: e.target.value }))} style={{ width: '100%' }}>
              <option value="">--</option>
              {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
        </div>
        <div className="row space-between" style={{ marginTop: 16 }}>
          <button className="btn secondary" onClick={onClose}>Hủy</button>
          <button className="btn primary" onClick={save}>💾 Lưu</button>
        </div>
      </div>
    </div>
  );
}

function ResetModal({ user, onClose }) {
  const [pw, setPw] = useState('');
  const submit = async () => {
    if (pw.length < 6) return alert('Mật khẩu ≥ 6 ký tự');
    try {
      await api.post(`/api/users/${user.id}/reset-password`, { new_password: pw });
      alert(`Đã đặt lại mật khẩu cho ${user.username}`);
      onClose();
    } catch (e) { alert(e.message); }
  };
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <h3>Đặt lại mật khẩu — {user.username}</h3>
        <input type="password" placeholder="Mật khẩu mới (≥ 6)" value={pw} onChange={e => setPw(e.target.value)} style={{ width: '100%', marginBottom: 16 }} />
        <div className="row space-between">
          <button className="btn secondary" onClick={onClose}>Hủy</button>
          <button className="btn primary" onClick={submit}>Đặt lại</button>
        </div>
      </div>
    </div>
  );
}
